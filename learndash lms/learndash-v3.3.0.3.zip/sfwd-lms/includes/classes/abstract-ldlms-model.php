<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

class LDLMS_Exception_NotFound extends Exception {}

abstract class LDLMS_Model {
	public function __construct() {
	}
}



