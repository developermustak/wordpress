<?php
require_once __DIR__ . '/includes/class-ld-themes-register.php';
