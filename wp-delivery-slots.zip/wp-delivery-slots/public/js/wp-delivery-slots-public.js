(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

jQuery(document).ready(function($) { 

jQuery('#datepicker-date').datepicker({ 
		onSelect: function(dateText, inst) {			
			jQuery.ajax({
			type : "post",
			dataType : "json",
			url : ajaxurl,
			data : {action: 'getDeliverySlots'},
			success: function(response) {
				if(response.html){
					jQuery('#modal-slots .modal-body').html(response.html);
					jQuery('#modal-slots').modal('show');
				}else{
					console.log('there is not any slots according to this data');
				}
			}
		}) 
		},
		minDate: 0,
		dateFormat: 'dd-mm-yy'
	});

	jQuery( 'body' ).on('change', '.select-you-delivery', function( e ) {	
		var link = this;
		var id   = jQuery( link ).attr( 'data-id' );
		var nonce = jQuery( link ).attr( 'data-nonce' );			
		jQuery.ajax({
			type : "post",
			dataType : "json",
			url : ajaxurl,
			data : {action: 'getCurrentDeliverySlots', pid: id, nonce: nonce },
			success: function(response) {
			if(response.slotsData) {
			$('.wp_slots_delivery_date_list').html(response.slotsData);
			jQuery('#modal-slots').modal('show'); 
			}
			else {
			console.log("Your vote could not be added")
			}
			}
		}) 
		// Prevent the default behavior for the link
		e.preventDefault();
	});

	jQuery('body').on('change', '.single-time-slot', function(){
		var id   = jQuery( this ).attr( 'data-id' );
		var currentSlot = $(this).data('id');
		var data = {
			action: 'woo_add_cart_fee',
			pid: id,
		};
		jQuery.ajax({
			type: 'POST',
			url: ajaxurl,
			data: data,
			success: function (code) {
			jQuery('body').trigger('update_checkout');
			jQuery("#hidden-slot-time").val(currentSlot);
			jQuery('#modal-slots').modal('hide'); 
				
			}
		});

	});

	
	// jQuery('body').on('click', '.thwmscf-buttons .button-next', function () {
	// 	alert('sdfa');
	// });

	});


})( jQuery );
