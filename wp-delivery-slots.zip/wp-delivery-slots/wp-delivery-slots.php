<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://netqom.com
 * @since             1.0.0
 * @package           Wp_Delivery_Slots
 *
 * @wordpress-plugin
 * Plugin Name:       Display delivery slots
 * Plugin URI:        https://netqom.com
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            Mustaq
 * Author URI:        https://netqom.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wp-delivery-slots
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'WP_DELIVERY_SLOTS_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wp-delivery-slots-activator.php
 */
add_action( 'init', 'activate_wp_delivery_slots' );
function activate_wp_delivery_slots() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wp-delivery-slots-activator.php';
	Wp_Delivery_Slots_Activator::activate();
}
/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wp-delivery-slots-deactivator.php
 */
function deactivate_wp_delivery_slots() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wp-delivery-slots-deactivator.php';
	Wp_Delivery_Slots_Deactivator::deactivate();
	unregister_post_type( 'wpdeliveryslots' );
}

register_activation_hook( __FILE__, 'activate_wp_delivery_slots' );
register_deactivation_hook( __FILE__, 'deactivate_wp_delivery_slots' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-wp-delivery-slots.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wp_delivery_slots() {

	$plugin = new Wp_Delivery_Slots();
	$plugin->run();

}

add_action('woocommerce_after_checkout_validation', 'custom_checkout_field_validation_process', 20, 2 );
function custom_checkout_field_validation_process( $data, $errors ) {

    // Check if set, if not add an error.
   if( isset($_POST['wp_slots_delivery_date']) && empty($_POST['wp_slots_delivery_date']))
      $errors->add( 'wp_slots_delivery_date', __( "Please select your delivery type first", "woocommerce" ) );

   if( isset($_POST['wp_hidden-slot-time'])  && empty($_POST['wp_hidden-slot-time']) )
   $errors->add( 'wp_hidden-slot-time', __( "Please select your time slot for this delivery type.. ", "woocommerce" ) );
}
add_action('woocommerce_after_order_notes', 'custom_checkout_field');

function custom_checkout_field($checkout)
{
	echo '<div id="custom_checkout_field"><h2></h2>';

	woocommerce_form_field('wp_slots_delivery_date', array(
	'type' => 'text',
	'id' => 'datepicker-date',
	'required'    => true,
   'autocomplete'=> 'off',
	'readonly'    => true,
	'class' => array(
		'datepicker-for-date-slot form-row-wide'
	),
	'label' => __('Please Select your delivery date.') ,
	'placeholder' => __('Please select your date') ,
	),
	$checkout->get_value('wp_slots_delivery_date'));

	woocommerce_form_field('wp_hidden-slot-time', 
		array(
			'type' => 'hidden',
			'id' => 'hidden-slot-time',
			'required'    => true,
			'class' => array(
				'my-field-class-slot form-row-wide'
			),
		),
		$checkout->get_value('wp_slots_delivery_date')
	);

	echo '
	</div>
	<script type="text/javascript">
	    var ajaxurl = "'.admin_url('admin-ajax.php').'";
	</script>
	';


}

add_action( 'wp_ajax_getDeliverySlots', 'getDeliverySlots' );
add_action( 'wp_ajax_nopriv_getDeliverySlots', 'getDeliverySlots' );
function getDeliverySlots()
{
	$args = array( 
	  'numberposts'		=> -1, // -1 is for all
	  'post_type'		=> 'wpdeliveryslots', // or 'post', 'page'
	  'orderby' 		=> 'title', // or 'date', 'rand'
	  'order' 		=> 'DESC', // or 'DESC'
	);

	// Get the posts
	$myposts = get_posts($args);
	if($myposts):
		$html = '';
		$html .= '<div class="slots"><ul class="wp_slots_delivery_date_list">';
		foreach ($myposts as $mypost):
			$nonce = wp_create_nonce( 'select-slot' . $mypost->ID );
			$html .= '<li><label><input type="radio" class="select-you-delivery" name="select_delivery" data-nonce="'.$nonce.'"  data-id="'.$mypost->ID.'" value="'.$mypost->post_title.'">'.$mypost->post_title.'</label><span class="del-price green">  -  Rs. '.get_field('delivery_fee', $mypost->ID).' </span></li>';
		endforeach;
		wp_reset_postdata(); 
		$html .= '</ul></div>';
		//return $html;

	endif; 
	echo json_encode(array('html'=>$html, 'status' => 'success'));
	die();
}


add_action( 'wp_ajax_getCurrentDeliverySlots', 'getCurrentDeliverySlots' );
add_action( 'wp_ajax_nopriv_getCurrentDeliverySlots', 'getCurrentDeliverySlots' );
function getCurrentDeliverySlots(){

	if( have_rows('time_setings', $_POST['pid']) ):
		$slotsData ='';
		while( have_rows('time_setings', $_POST['pid']) ): the_row();

			$timefrom = get_sub_field('select_time_slot_from');
			$timeto = get_sub_field('select_time_slot_to');

			$timefrom = get_sub_field('select_time_slot_from');

			$slotsData .= 
			'<li class="leaf"><label><input type="radio" class="single-time-slot" name="delivery-slot" data-id="'.$_POST['pid'].'"> '.$timefrom.' - '.$timeto.'</label></li>';
		endwhile;

	endif;			
	echo json_encode(array('slotsData'=>$slotsData, 'status' => 'success'));
	die();
}


function woo_add_cart_fee(){
	if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return;

	//WC()->cart->add_fee(__('Delivery Fese', 'delivery_fee'), 0);
	if(isset($_POST['pid'])){
		$pid = $_POST['pid'];
		WC()->session->set( 'slotpid' , $pid );
	}
	if(! empty(WC()->session->get( 'slotpid'))){
		$delivery_fee = get_field('delivery_fee', WC()->session->get( 'slotpid'));
		WC()->cart->add_fee(__('Delivery Fee', 'delivery_fee'), $delivery_fee);
	}
}
add_action( 'woocommerce_cart_calculate_fees', 'woo_add_cart_fee' );


add_action('wp_ajax_woo_add_cart_fee', 'woo_add_cart_fee', 10);
add_action('wp_ajax_nopriv_woo_add_cart_fee', 'woo_add_cart_fee', 10);

function wpse_enqueue_datepicker() {
	   
    // Load the datepicker script (pre-registered in WordPress).
    wp_enqueue_script( 'jquery-ui-datepicker' );

    // You need styling for the datepicker. For simplicity I've linked to the jQuery UI CSS on a CDN.
    wp_register_style( 'jquery-ui', 'https://code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css' );
    wp_enqueue_style( 'jquery-ui' );  
   wp_register_style( 'jquery-modal-css', 'https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css' );
    wp_enqueue_style( 'jquery-modal-css' );  
// <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0/jquery.min.js"></script>

	wp_enqueue_script( 'jquery-modal', 'https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js' );
    wp_enqueue_script('jquery-modal');


}
add_action( 'wp_enqueue_scripts', 'wpse_enqueue_datepicker' );

add_action('wp_footer', 'add_slots_modal_to_footer'); 
function add_slots_modal_to_footer() { 
    echo '
<div class="modal fade" id="modal-slots" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Select Delivery Type & Slot</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      </div>
    </div>
  </div>
</div>'; 
}

run_wp_delivery_slots();
