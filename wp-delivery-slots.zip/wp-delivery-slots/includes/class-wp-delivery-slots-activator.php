<?php

/**
 * Fired during plugin activation
 *
 * @link       https://netqom.com
 * @since      1.0.0
 *
 * @package    Wp_Delivery_Slots
 * @subpackage Wp_Delivery_Slots/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wp_Delivery_Slots
 * @subpackage Wp_Delivery_Slots/includes
 * @author     Mustaq <testing@gmail.com>
 */
class Wp_Delivery_Slots_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		//die('ssdfs');

	register_post_type( 'wpdeliveryslots',
        array(
            'labels' => array(
                'name' => __( 'WP Delivery Slots' ),
                'singular_name' => __( 'Delivery Type' )
                ),
        'public' => true,
        'has_archive' => true,
        'rewrite' => array( 'slug' => 'wp-delivery-slots' )
        )
    );
    remove_post_type_support( 'wpdeliveryslots', 'editor' );

	}

}
